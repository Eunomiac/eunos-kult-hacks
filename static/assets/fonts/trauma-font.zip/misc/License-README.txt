Thank you for downloading my font.

This font is for PERSONAL USE only. Please contact me for a commercial use license.

Crediting me is not required, but I would like to see where and how my fonts are being used.

-----

Yu Lee 
mail@yupenglee.com
www.yupenglee.com